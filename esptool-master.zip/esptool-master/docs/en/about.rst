About
=====

Esptool was started by Fredrik Ahlberg (`themadinventor <https://github.com/themadinventor>`_) as an unofficial community project. Later, it was maintained by Angus Gratton (`projectgus <https://github.com/projectgus>`_). It is now supported by `Espressif Systems <https://espressif.com/>`_.

Esptool source code and this documentation are released as Free Software under GNU General Public License Version 2 or later. See `the LICENSE <https://github.com/espressif/esptool/blob/master/LICENSE>`_ for a copy.
